# 🧪 Test Examples

## Local Testing

### Start the Server
```bash
cd pdf-service
npm install
npm start
```

Server runs on `http://localhost:3000`

---

## Health Check Tests

### Basic Health Check
```bash
curl http://localhost:3000/
```

**Expected Response:**
```json
{
  "status": "PDF Service Running",
  "version": "1.0.0",
  "clubs": ["salem", "keizer", "corvallis"]
}
```

---

## PDF Generation Tests (No ABC Upload)

### Minimal Data Test
```bash
curl -X POST http://localhost:3000/test-pdf-generation \
  -H "Content-Type: application/json" \
  -d '{
    "firstName": "Test",
    "lastName": "User",
    "email": "test@example.com",
    "location_id": "uflpfHNpByAnaBLkQzu3"
  }'
```

### Full Data Test (No Signature)
```bash
curl -X POST http://localhost:3000/test-pdf-generation \
  -H "Content-Type: application/json" \
  -d '{
    "firstName": "John",
    "lastName": "Doe",
    "email": "john@example.com",
    "phone": "+15035551234",
    "streetAddress": "123 Main St",
    "city": "Salem",
    "state": "Oregon",
    "postalCode": "97301",
    "dob": "1990-01-15",
    "location_id": "uflpfHNpByAnaBLkQzu3"
  }'
```

### Full Data with Signature
```bash
curl -X POST http://localhost:3000/test-pdf-generation \
  -H "Content-Type: application/json" \
  -d '{
    "firstName": "Justin",
    "lastName": "Huttinger",
    "email": "justin@wcstrength.com",
    "phone": "+14259549854",
    "streetAddress": "290 Moyer Lane Northwest",
    "city": "Salem",
    "state": "Oregon",
    "postalCode": "97304",
    "dob": "1990-01-15",
    "location_id": "uflpfHNpByAnaBLkQzu3",
    "signatureUrl": "https://services.leadconnectorhq.com/documents/download/a1f4iaVIF61gyBk3q5xl",
    "terms": "I agree to terms & conditions",
    "submissionDate": "2025-11-12T16:31:12Z"
  }'
```

### Test Different Clubs
```bash
# Salem
curl -X POST http://localhost:3000/test-pdf-generation \
  -H "Content-Type: application/json" \
  -d '{"firstName":"Test","lastName":"Salem","email":"test@salem.com","location_id":"uflpfHNpByAnaBLkQzu3"}'

# Keizer (update location_id)
curl -X POST http://localhost:3000/test-pdf-generation \
  -H "Content-Type: application/json" \
  -d '{"firstName":"Test","lastName":"Keizer","email":"test@keizer.com","location_id":"YOUR_KEIZER_LOCATION_ID"}'
```

---

## Full Integration Tests (With ABC Upload)

⚠️ **Warning**: These tests will upload to ABC Financial. Only use in production with valid member IDs.

### Test Full Flow
```bash
curl -X POST http://localhost:3000/ghl-trial-form \
  -H "Content-Type: application/json" \
  -d '{
    "firstName": "Test",
    "lastName": "Member",
    "email": "test@wcstrength.com",
    "phone": "+15035551234",
    "streetAddress": "123 Test St",
    "city": "Salem",
    "state": "Oregon",
    "postalCode": "97301",
    "dob": "1990-01-15",
    "location_id": "uflpfHNpByAnaBLkQzu3",
    "signatureUrl": "https://services.leadconnectorhq.com/documents/download/a1f4iaVIF61gyBk3q5xl"
  }'
```

**Expected Success Response:**
```json
{
  "success": true,
  "pdf_generated": true,
  "abc_upload": true,
  "club": "West Coast Strength Salem",
  "fileName": "Trial_Form_Test_Member_1699876543210.pdf",
  "memberId": "test@wcstrength.com",
  "abc_document_id": "doc_xyz123",
  "message": "PDF generated and uploaded successfully"
}
```

---

## Simulating GHL Webhooks

### GHL Contact-Based Webhook
```bash
curl -X POST http://localhost:3000/ghl-trial-form \
  -H "Content-Type: application/json" \
  -d '{
    "contact": {
      "first_name": "John",
      "last_name": "Doe",
      "email": "john@example.com",
      "phone": "+15035551234",
      "address1": "123 Main St",
      "city": "Salem",
      "state": "Oregon",
      "postal_code": "97301",
      "date_of_birth": "1990-01-15"
    },
    "location_id": "uflpfHNpByAnaBLkQzu3",
    "form": {
      "signature_url": "https://services.leadconnectorhq.com/documents/download/abc123"
    }
  }'
```

### GHL Submission-Based Webhook
```bash
curl -X POST http://localhost:3000/ghl-trial-form \
  -H "Content-Type: application/json" \
  -d '{
    "submissionData": {
      "firstName": "Jane",
      "lastName": "Smith",
      "email": "jane@example.com",
      "phone": "+15035559999",
      "streetAddress": "456 Oak Ave",
      "city": "Salem",
      "state": "Oregon",
      "postalCode": "97302",
      "dob": "1985-03-22",
      "signatureUrl": "https://services.leadconnectorhq.com/documents/download/xyz789"
    },
    "locationId": "uflpfHNpByAnaBLkQzu3"
  }'
```

---

## Testing Field Name Variations

The service handles different field name formats:

### Snake Case Fields
```bash
curl -X POST http://localhost:3000/test-pdf-generation \
  -H "Content-Type: application/json" \
  -d '{
    "first_name": "Test",
    "last_name": "User",
    "email": "test@test.com",
    "phone_number": "+15035551234",
    "street_address": "123 Main St",
    "postal_code": "97301",
    "date_of_birth": "1990-01-15",
    "location_id": "uflpfHNpByAnaBLkQzu3"
  }'
```

### Camel Case Fields
```bash
curl -X POST http://localhost:3000/test-pdf-generation \
  -H "Content-Type: application/json" \
  -d '{
    "firstName": "Test",
    "lastName": "User",
    "email": "test@test.com",
    "phoneNumber": "+15035551234",
    "streetAddress": "123 Main St",
    "postalCode": "97301",
    "dateOfBirth": "1990-01-15",
    "locationId": "uflpfHNpByAnaBLkQzu3"
  }'
```

---

## Decoding PDF from Response

### Save and View PDF

```bash
# Save response to file
curl -X POST http://localhost:3000/test-pdf-generation \
  -H "Content-Type: application/json" \
  -d '{"firstName":"Test","lastName":"User","email":"test@test.com","location_id":"uflpfHNpByAnaBLkQzu3"}' \
  > response.json

# Extract and decode PDF (Mac/Linux)
cat response.json | jq -r '.pdf' | base64 -d > test.pdf

# Open the PDF
open test.pdf  # Mac
xdg-open test.pdf  # Linux
```

### Using Node.js Script
```javascript
const fs = require('fs');

// Read response
const response = JSON.parse(fs.readFileSync('response.json', 'utf8'));

// Decode base64 PDF
const pdfBuffer = Buffer.from(response.pdf, 'base64');

// Save to file
fs.writeFileSync('test.pdf', pdfBuffer);

console.log('PDF saved as test.pdf');
```

---

## Error Condition Tests

### Missing Required Fields
```bash
curl -X POST http://localhost:3000/ghl-trial-form \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@test.com"
  }'
```

**Expected Error:**
```json
{
  "success": false,
  "error": "Missing required fields"
}
```

### Invalid Location ID
```bash
curl -X POST http://localhost:3000/ghl-trial-form \
  -H "Content-Type: application/json" \
  -d '{
    "firstName": "Test",
    "lastName": "User",
    "email": "test@test.com",
    "location_id": "INVALID_ID"
  }'
```

**Expected Error:**
```json
{
  "success": false,
  "error": "Unable to identify club",
  "received_location_id": "INVALID_ID"
}
```

### Invalid Signature URL
```bash
curl -X POST http://localhost:3000/test-pdf-generation \
  -H "Content-Type: application/json" \
  -d '{
    "firstName": "Test",
    "lastName": "User",
    "email": "test@test.com",
    "location_id": "uflpfHNpByAnaBLkQzu3",
    "signatureUrl": "https://invalid-url.com/fake.png"
  }'
```

PDF will generate, but signature section will show error or be empty.

---

## Production Testing

### Test Against Deployed Service

Replace `localhost:3000` with your Render URL:

```bash
curl https://wcs-pdf-service.onrender.com/

curl -X POST https://wcs-pdf-service.onrender.com/test-pdf-generation \
  -H "Content-Type: application/json" \
  -d '{"firstName":"Test","lastName":"User","email":"test@test.com","location_id":"uflpfHNpByAnaBLkQzu3"}'
```

### Test from GHL

1. Go to GHL → Workflows
2. Find your trial form workflow
3. Click "Test" or submit a real form
4. Check Render logs for the webhook

---

## Postman Collection

If you prefer Postman, import this collection:

```json
{
  "info": {
    "name": "WCS PDF Service",
    "schema": "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"
  },
  "item": [
    {
      "name": "Health Check",
      "request": {
        "method": "GET",
        "url": "{{base_url}}/"
      }
    },
    {
      "name": "Test PDF Generation",
      "request": {
        "method": "POST",
        "url": "{{base_url}}/test-pdf-generation",
        "header": [
          {
            "key": "Content-Type",
            "value": "application/json"
          }
        ],
        "body": {
          "mode": "raw",
          "raw": "{\n  \"firstName\": \"Test\",\n  \"lastName\": \"User\",\n  \"email\": \"test@test.com\",\n  \"location_id\": \"uflpfHNpByAnaBLkQzu3\"\n}"
        }
      }
    },
    {
      "name": "Full Integration Test",
      "request": {
        "method": "POST",
        "url": "{{base_url}}/ghl-trial-form",
        "header": [
          {
            "key": "Content-Type",
            "value": "application/json"
          }
        ],
        "body": {
          "mode": "raw",
          "raw": "{\n  \"firstName\": \"Test\",\n  \"lastName\": \"Member\",\n  \"email\": \"test@wcstrength.com\",\n  \"phone\": \"+15035551234\",\n  \"location_id\": \"uflpfHNpByAnaBLkQzu3\"\n}"
        }
      }
    }
  ],
  "variable": [
    {
      "key": "base_url",
      "value": "http://localhost:3000"
    }
  ]
}
```

**Environment Variables:**
- `base_url`: `http://localhost:3000` (local) or `https://wcs-pdf-service.onrender.com` (production)

---

## Automated Testing Script

Create `test.sh`:

```bash
#!/bin/bash

BASE_URL="http://localhost:3000"

echo "Testing PDF Service..."
echo ""

echo "1. Health Check"
curl -s $BASE_URL/ | jq
echo ""

echo "2. Test PDF Generation - Minimal"
curl -s -X POST $BASE_URL/test-pdf-generation \
  -H "Content-Type: application/json" \
  -d '{"firstName":"Test","lastName":"Min","email":"test@test.com","location_id":"uflpfHNpByAnaBLkQzu3"}' \
  | jq '.success, .club, .fileName'
echo ""

echo "3. Test PDF Generation - Full"
curl -s -X POST $BASE_URL/test-pdf-generation \
  -H "Content-Type: application/json" \
  -d '{"firstName":"Test","lastName":"Full","email":"test@test.com","phone":"+15035551234","streetAddress":"123 Main St","city":"Salem","state":"Oregon","postalCode":"97301","location_id":"uflpfHNpByAnaBLkQzu3"}' \
  | jq '.success, .club, .fileName'
echo ""

echo "4. Test Invalid Location"
curl -s -X POST $BASE_URL/test-pdf-generation \
  -H "Content-Type: application/json" \
  -d '{"firstName":"Test","lastName":"Invalid","email":"test@test.com","location_id":"INVALID"}' \
  | jq '.success, .error'
echo ""

echo "All tests complete!"
```

Run: `chmod +x test.sh && ./test.sh`

---

## Monitoring Real Usage

### Watch Logs in Real-Time

```bash
# If you have Render CLI installed
render logs -f wcs-pdf-service

# Or use Render Dashboard
# Dashboard → wcs-pdf-service → Logs (set to "Live")
```

### Common Log Patterns

**Success:**
```
Received webhook from GHL
Processing form for West Coast Strength Salem
PDF generated successfully: Trial_Form_John_Doe_1699876543210.pdf
Successfully uploaded to ABC Financial for member: john@example.com
```

**Partial Success:**
```
Received webhook from GHL
Processing form for West Coast Strength Salem
PDF generated successfully: Trial_Form_John_Doe_1699876543210.pdf
ABC Financial upload failed: Connection timeout
```

**Error:**
```
Received webhook from GHL
Unable to identify club from data
```

---

**Pro tip**: Start with `/test-pdf-generation` endpoint to verify PDFs look good before enabling ABC uploads!
