# ⚡ Quick Reference

## Essential Commands

### First Time Setup
```bash
cd pdf-service
git init
git add .
git commit -m "Initial setup"
git remote add origin https://github.com/YOUR_USERNAME/wcs-pdf-service.git
git push -u origin main
```

### Update Club Configuration
Edit `index.js` lines 10-30:
```javascript
const CLUBS = {
  'salem': {
    name: 'West Coast Strength Salem',
    location_id: 'uflpfHNpByAnaBLkQzu3',
    club_id: 'SALEM_ABC_CLUB_ID'
  }
  // Add your 7 clubs here
};
```

### Test Locally
```bash
npm install
npm start
# Open http://localhost:3000 in browser
```

### Test API
```bash
# Health check
curl http://localhost:3000/

# Test PDF generation (no ABC upload)
curl -X POST http://localhost:3000/test-pdf-generation \
  -H "Content-Type: application/json" \
  -d '{"firstName":"Test","lastName":"User","email":"test@test.com","location_id":"uflpfHNpByAnaBLkQzu3"}'

# Full flow test (with ABC upload - only in production)
curl -X POST http://localhost:3000/ghl-trial-form \
  -H "Content-Type: application/json" \
  -d '{"firstName":"Test","lastName":"User","email":"test@test.com","location_id":"uflpfHNpByAnaBLkQzu3"}'
```

### Deploy Updates
```bash
git add .
git commit -m "Updated clubs"
git push
# Render auto-deploys from GitHub (~2 minutes)
```

## GHL Webhook Setup

**URL**: `https://wcs-pdf-service.onrender.com/ghl-trial-form`

**Method**: POST

**Required Fields**:
- firstName (or first_name)
- lastName (or last_name)
- email
- location_id (for club identification)

**Recommended Fields**:
- phone
- streetAddress
- city
- state
- postalCode
- dob
- signatureUrl
- submissionDate

**Example Webhook Payload**:
```json
{
  "firstName": "{{contact.first_name}}",
  "lastName": "{{contact.last_name}}",
  "email": "{{contact.email}}",
  "phone": "{{contact.phone}}",
  "streetAddress": "{{contact.address1}}",
  "city": "{{contact.city}}",
  "state": "{{contact.state}}",
  "postalCode": "{{contact.postal_code}}",
  "dob": "{{contact.date_of_birth}}",
  "location_id": "{{location.id}}",
  "signatureUrl": "{{form.signature_url}}",
  "submissionDate": "{{contact.date_added}}"
}
```

## Render Environment Variables

Set these in Render Dashboard → Your Service → Environment:

```
ABC_API_URL = https://your-abc-endpoint.com/documents/upload
ABC_API_KEY = your_abc_api_key_here
NODE_ENV = production
```

## Response Formats

### Success Response
```json
{
  "success": true,
  "pdf_generated": true,
  "abc_upload": true,
  "club": "West Coast Strength Salem",
  "fileName": "Trial_Form_John_Doe_1699876543210.pdf",
  "memberId": "john@example.com",
  "abc_document_id": "doc_xyz123",
  "message": "PDF generated and uploaded successfully"
}
```

### Partial Success (PDF worked, ABC failed)
```json
{
  "success": true,
  "pdf_generated": true,
  "abc_upload": false,
  "abc_error": "Connection timeout",
  "club": "West Coast Strength Salem",
  "fileName": "Trial_Form_John_Doe_1699876543210.pdf",
  "message": "PDF generated but ABC upload failed"
}
```

### Error Response
```json
{
  "success": false,
  "error": "Unable to identify club",
  "received_location_id": "unknown_id"
}
```

## Troubleshooting Quick Fixes

**Service won't start?**
```bash
# Check Render logs:
# Dashboard → wcs-pdf-service → Logs

# Test locally:
npm install
npm start
```

**PDF not generating?**
```bash
# Test with minimal data:
curl -X POST http://localhost:3000/test-pdf-generation \
  -H "Content-Type: application/json" \
  -d '{"firstName":"Test","lastName":"User","email":"test@test.com"}'
```

**Wrong club identified?**
- Verify location_id is sent in webhook
- Check CLUBS config matches GHL location IDs
- Look at logs to see what location_id was received

**ABC upload failing?**
- Check environment variables in Render
- Verify ABC_API_URL and ABC_API_KEY
- Test ABC API credentials independently
- Check if member exists in ABC first

**Webhook not triggering?**
1. Verify webhook URL has no typos
2. Check GHL workflow is active
3. Verify Render service is running
4. Look at GHL workflow execution history
5. Test manually with curl

## Monitoring

**View Logs**:
```
Render Dashboard → wcs-pdf-service → Logs tab
```

**Success indicators**:
- ✅ "Processing form for West Coast Strength Salem"
- ✅ "PDF generated successfully"
- ✅ "Successfully uploaded to ABC Financial"

**Warning signs**:
- ⚠️ "PDF generated but ABC upload failed"
- ❌ "Unable to identify club"
- ❌ "Error processing webhook"

## Field Name Mapping

The service accepts various field names automatically:

| Field | Accepted Names |
|-------|----------------|
| First Name | firstName, first_name, name (first word) |
| Last Name | lastName, last_name, name (rest) |
| Email | email, email_address |
| Phone | phone, phone_number, phoneNumber |
| Address | streetAddress, address, address1, street |
| City | city |
| State | state |
| Zip | postalCode, zip, zipCode, postal_code |
| DOB | dob, dateOfBirth, date_of_birth, birthdate |
| Signature | signatureUrl, signature, signature_url |

## Getting Location IDs

**From GHL:**
1. Submit test form
2. Check webhook payload in Render logs
3. Look for `location_id` field

**From Email Headers:**
Look for: `X-Mailgun-Tag: loc_XXXXXXXXX`

**From GHL UI:**
Settings → Locations → Copy Location ID

## Key Files

- `index.js` - Main code (edit for clubs/logic)
- `package.json` - Dependencies (rarely change)
- `README.md` - Overview documentation
- `SETUP_GUIDE.md` - Deployment walkthrough
- `ARCHITECTURE.md` - System design details
- `TEST_EXAMPLES.md` - Testing commands

## Support URLs

- **Render Dashboard**: https://dashboard.render.com
- **Render Logs**: Dashboard → Your Service → Logs
- **GitHub Repo**: https://github.com/YOUR_USERNAME/wcs-pdf-service
- **Service URL**: https://wcs-pdf-service.onrender.com

## Common Patterns

**Add new club:**
1. Edit `index.js` CLUBS object
2. Git commit and push
3. Render auto-deploys
4. Configure GHL webhook for that location

**Change PDF layout:**
1. Edit `buildTrialFormHTML` function in `index.js`
2. Test locally first
3. Git commit and push

**Update ABC API:**
1. Edit `uploadToABCFinancial` function
2. Update environment variables if needed
3. Test with `/test-pdf-generation` first
4. Deploy

**Debug webhook issues:**
1. Check Render logs for incoming data
2. Look for JSON parsing errors
3. Verify field names match expectations
4. Test with curl using exact GHL format

---

**Pro tip**: Keep this file open while troubleshooting! 🎯
