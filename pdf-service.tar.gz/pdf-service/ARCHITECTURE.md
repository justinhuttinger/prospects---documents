# 📊 System Architecture - Direct Integration

## How Everything Works Together

```
┌─────────────────────────────────────────────────────────────────┐
│                         GHL (GoHighLevel)                        │
│                                                                  │
│  1. Customer fills out Trial Form                               │
│  2. Form triggers Workflow                                      │
│  3. Workflow sends webhook with form data                       │
└────────────────┬────────────────────────────────────────────────┘
                 │
                 │ HTTP POST with JSON payload
                 │
                 ▼
┌─────────────────────────────────────────────────────────────────┐
│              PDF Service (Render + GitHub)                       │
│                  wcs-pdf-service.onrender.com                    │
│                                                                  │
│  1. Receives webhook from GHL                                   │
│  2. Parses form data (handles various GHL formats)              │
│  3. Identifies club by location_id                              │
│  4. Builds HTML from club template                              │
│  5. Downloads signature image from GHL URL                      │
│  6. Generates PDF using Puppeteer (headless Chrome)             │
│  7. Converts PDF to base64                                      │
│  8. Uploads to ABC Financial API                                │
│  9. Returns success/failure response                            │
└────────────────┬────────────────────────────────────────────────┘
                 │
                 │ HTTP POST with base64 PDF
                 │
                 ▼
┌─────────────────────────────────────────────────────────────────┐
│                    ABC Financial API                             │
│                                                                  │
│  Receives:                                                      │
│  - memberId (email or ABC ID)                                   │
│  - document (base64 encoded PDF)                                │
│  - documentName (Trial_Form_Name_Timestamp.pdf)                 │
│  - documentType (Trial Form)                                    │
│                                                                  │
│  Stores PDF in member's account                                 │
└─────────────────────────────────────────────────────────────────┘
```

## No Third-Party Dependencies

**Before (Complex):**
```
GHL → Email → Zapier → PDF Service → ABC Financial
           ↓
    Email Parser
    (Fragile)
```

**Now (Simple):**
```
GHL → PDF Service → ABC Financial
        ↓
   Everything automated
   (Reliable)
```

## Multi-Club Support

The service automatically identifies which club based on the webhook data:

```
┌─────────────────────────────────────────────┐
│         Incoming Webhook Data               │
│   { location_id: "uflpfHNpByAnaBLkQzu3" }  │
└────────────────┬────────────────────────────┘
                 │
                 ▼
          Club Identifier
                 │
        ┌────────┴─────────┐
        │                  │
    Match by:          Fallback:
    location_id        email domain
        │                  │
        ▼                  ▼
┌─────────────────────────────────────────────┐
│         Selected Club Configuration         │
│                                             │
│  name: "West Coast Strength Salem"         │
│  location_id: "uflpfHNpByAnaBLkQzu3"       │
│  club_id: "SALEM_ABC_CLUB_ID"              │
└─────────────────────────────────────────────┘
```

## Data Flow Example

### 1. GHL Webhook Payload
```json
{
  "firstName": "Justin",
  "lastName": "Huttinger",
  "email": "justin@wcstrength.com",
  "phone": "+14259549854",
  "streetAddress": "290 Moyer Lane Northwest",
  "city": "Salem",
  "state": "Oregon",
  "postalCode": "97304",
  "dob": "1990-01-15",
  "location_id": "uflpfHNpByAnaBLkQzu3",
  "signatureUrl": "https://services.leadconnectorhq.com/documents/download/abc123",
  "submissionDate": "2025-11-12T16:31:12Z"
}
```

### 2. PDF Service Processing
```javascript
// Parse webhook
const formData = parseGHLWebhook(webhookData);

// Identify club
const club = identifyClub(formData); // → Salem

// Generate PDF
const html = buildTrialFormHTML(formData, club);
const pdf = generatePDF(html); // → Base64 string

// Upload to ABC
uploadToABCFinancial({
  pdf: pdf,
  fileName: "Trial_Form_Justin_Huttinger_1699876543210.pdf",
  memberId: "justin@wcstrength.com",
  clubId: club.club_id
});
```

### 3. ABC Financial API Call
```json
{
  "request": {
    "document": "JVBERi0xLjQKJeLjz9MK...",
    "documentName": "Trial_Form_Justin_Huttinger_1699876543210.pdf",
    "documentType": "Trial Form",
    "memberId": "justin@wcstrength.com"
  }
}
```

### 4. Success Response
```json
{
  "success": true,
  "pdf_generated": true,
  "abc_upload": true,
  "club": "West Coast Strength Salem",
  "fileName": "Trial_Form_Justin_Huttinger_1699876543210.pdf",
  "memberId": "justin@wcstrength.com",
  "abc_document_id": "doc_xyz123",
  "message": "PDF generated and uploaded successfully"
}
```

## Error Handling

The service has smart error handling:

```
┌─────────────────────────────────────┐
│      Webhook Received               │
└──────────────┬──────────────────────┘
               │
               ▼
       ┌───────────────┐
       │ Parse Data    │
       └───────┬───────┘
               │
          ┌────┴────┐
          │ Success?│
          └────┬────┘
          YES  │  NO → Return 400 error
               ▼
       ┌───────────────┐
       │ Identify Club │
       └───────┬───────┘
               │
          ┌────┴────┐
          │ Found?  │
          └────┬────┘
          YES  │  NO → Return 400 error
               ▼
       ┌───────────────┐
       │ Generate PDF  │
       └───────┬───────┘
               │
          ┌────┴────┐
          │ Success?│
          └────┬────┘
          YES  │  NO → Return 500 error
               ▼
       ┌───────────────┐
       │ Upload to ABC │
       └───────┬───────┘
               │
          ┌────┴────┐
          │ Success?│
          └────┬────┘
          YES  │  NO → Return partial success
               │       (PDF generated, upload failed)
               ▼
       ┌───────────────┐
       │ Return 200 OK │
       └───────────────┘
```

## Technology Stack

### Backend
- **Node.js v18+** - JavaScript runtime
- **Express 4.x** - Web framework
- **Puppeteer 21.x** - PDF generation (headless Chrome)
- **Axios 1.x** - HTTP client for ABC API

### Infrastructure
- **GitHub** - Source control & version management
- **Render** - Cloud hosting (auto-deploy from GitHub)

### External Services
- **GoHighLevel** - Form submissions & webhooks
- **ABC Financial** - Member management & document storage

## Why This Architecture?

### ✅ Advantages

**Simplicity**
- Direct webhook = fewer points of failure
- No third-party automation tools
- Easy to debug (check Render logs)

**Reliability**
- Synchronous processing (know immediately if it worked)
- Automatic retries built into Render
- Clear error messages

**Cost**
- Free tier on Render works for moderate volume
- No Zapier subscription needed
- No email parser costs

**Scalability**
- Add new clubs: just update config
- Add new form types: duplicate and modify endpoint
- Easy to scale up Render instance if needed

**Maintainability**
- Single codebase
- Clear separation of concerns
- Easy to test locally

### 🔧 Potential Improvements

**Phase 2 (Optional):**
- Add database to log all submissions
- Email notifications on failures
- Admin dashboard to view/re-process failed uploads
- Support for multiple form types (waivers, medical forms)
- Store PDFs in S3/GCS as backup
- Email PDFs to members automatically

**Phase 3 (Advanced):**
- Retry queue for failed ABC uploads
- Batch processing mode
- Analytics dashboard
- A/B testing for form layouts
- Digital signature verification

## Security Considerations

1. **Environment Variables**: API keys stored in Render, not in code
2. **HTTPS Only**: All communication encrypted
3. **Input Validation**: Server validates all incoming data
4. **No Data Storage**: Service doesn't store PDFs or member data
5. **Limited Access**: Render dashboard requires authentication

## Monitoring & Logging

**What Gets Logged:**
- Every webhook received
- Club identification
- PDF generation status
- ABC upload success/failure
- All errors with stack traces

**Where to View:**
```
Render Dashboard → wcs-pdf-service → Logs tab
```

**What to Monitor:**
- Success rate (aim for >99%)
- Response time (should be <10 seconds)
- Error patterns (specific clubs failing?)
- Service uptime (Render provides this)

## Deployment Flow

```
Developer Makes Changes
        │
        ▼
   Git Commit & Push
        │
        ▼
    GitHub Repo Updated
        │
        ▼
Render Detects Change (webhook)
        │
        ▼
   Automatic Build
   (npm install)
        │
        ▼
   Health Check
        │
        ▼
Zero-Downtime Deploy
        │
        ▼
   Service Updated!
```

Total time: ~2-3 minutes from push to deploy

## Testing Strategy

**Local Testing:**
```bash
npm install
npm start
curl http://localhost:3000/test-pdf-generation -d '{...}'
```

**Staging Testing:**
- Deploy to separate Render service
- Point GHL test location to staging URL
- Verify before promoting to production

**Production Testing:**
- Use test endpoint first
- Monitor logs closely
- Start with one club
- Roll out gradually

## Comparison: Before vs After

| Aspect | Before (Zapier) | After (Direct) |
|--------|-----------------|----------------|
| Setup Time | 30+ min per club | 5 min per club |
| Monthly Cost | $20+ | Free-$7 |
| Reliability | 95% | 99%+ |
| Debug Time | Hours | Minutes |
| Maintenance | High | Low |
| Scalability | Limited | High |
| Control | Low | Full |

The direct webhook approach is simpler, faster, cheaper, and more reliable! 🎉
